import UIKit

//MARK: Implicit unwrapping:
var implicitUnwrappedString: String! = nil
print(implicitUnwrappedString)




